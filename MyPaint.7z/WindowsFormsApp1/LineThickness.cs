﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    //толщина контура
    internal enum LineThickness
    {
        Lighter = 1, Light=3,
        Bolder=7, Bold=5
    }
}
