﻿namespace WindowsFormsApp1
{
    //Направление ресайза
    public enum ResizeDirection
    {   // L - left, R - right, T - top, B - bottom
        None, L, R, T, B
    }
}
